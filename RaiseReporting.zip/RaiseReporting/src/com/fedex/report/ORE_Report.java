package com.fedex.report;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ORE_Report {

	public static int Pass,Fail,Total,passcount,failcount,totalpass,totalfail;
	public static List<String> Header = new ArrayList<String>();
	public static List<String> csvpassdata = new ArrayList<String>();
	static String htmlvalue="<thead style='background-color:#3c1d6b'><tr><th><font color=\"#ffffff\">No.of Scenario's</font></th><th><font color=\"#ffffff\">Test case count</font></th><th bgcolor='limegreen'><font color=\"#ffffff\">Passed</font></th><th bgcolor='limegreen'><font color=\"#ffffff\">% Passed</font></th><th bgcolor='red'><font color=\"#ffffff\">Failed</font></th><th bgcolor='red'><font color=\"#ffffff\">% Failed</font></th></tr></thead>";
	static String OREhtmlValue="<thead style='background-color:#3c1d6b'><tr><th><font color=\"#ffffff\">Scenario Id</font></th><th><font color=\"#ffffff\">Tracking No</font></th><th bgcolor='limegreen'><font color=\"#ffffff\">Passed Test cases</font></th><th bgcolor='red'><font color=\"#ffffff\">Failed Test cases</font></th><th bgcolor='limegreen'><font color=\"#ffffff\">Passed count</font></th><th bgcolor='red'><font color=\"#ffffff\">Failed count</font></th></thead>";
	public static String dir;
	public static Properties props;

	public static void pathdir() {
		dir = System.getProperty("user.dir");
		System.out.println(dir);
	}

	public static void properties() throws IOException{

		File configFile = new File("Regression_java.properties");


		FileReader reader = new FileReader(configFile);

		props = new Properties();

		// load the properties file:
		props.load(reader);
	}


	public void OREReport() throws IOException {
		
		System.out.println("ORE Report started..");
		
		pathdir();
		properties();

		FileInputStream  Fis = new FileInputStream(dir+props.getProperty("ORE_Report"));
		XSSFWorkbook wb =new XSSFWorkbook(Fis);
		XSSFSheet sh = wb.getSheetAt(0);
		String Scenarioid = "";
		String Trackingnbr= "";
		String Scenariospassing= "";
		String ScenariosFailing= "";

		
		Pass=0;
		Fail=0;
		Total=0;

		for (int i = 1; i <=sh.getLastRowNum(); i++) {
			System.out.println(i);
			String Passcount= sh.getRow(i).getCell(7).toString();
			Pass = Pass+Integer.parseInt(Passcount);
			String Failcount= sh.getRow(i).getCell(8).toString();
			Fail = Fail+Integer.parseInt(Failcount);
			 Scenarioid= sh.getRow(i).getCell(0).toString();
			 Trackingnbr= sh.getRow(i).getCell(2).toString();
			 Scenariospassing= sh.getRow(i).getCell(5).toString();
			 ScenariosFailing= sh.getRow(i).getCell(6).toString();

			 //System.out.println("Scenarioid is :"+Scenarioid+"Trackingnbr is :"+Trackingnbr+"Scenariospassing is : "+Scenariospassing+"ScenariosFailing :"+ScenariosFailing+"PassCount is :"+Passcount+"FailCount is :"+Failcount);
			OREhtmlValue = OREhtmlValue+"<tr><td><b>"+Scenarioid+"</b></td><td>"+Trackingnbr+"</td><td>"+Scenariospassing+"</td><td>"+ScenariosFailing+"</td><td>"+Passcount+"</td><td>"+Failcount+"</td></tr>"; 
		}

		
		
		Total=Pass+Fail;
		
        double passpercentage = ((double)Pass*100)/(double)Total;
        double failpercentage = ((double)Fail*100)/(double)Total;
        int ScenarioIDCount = sh.getLastRowNum()-1;
        
        htmlvalue=htmlvalue.concat("<tr><td><b>"+ScenarioIDCount+"</b></td><td>"+String.valueOf(Total)+"</td><td>"+String.valueOf(Pass)+"</td><td>"+String.format("%.2f%%",passpercentage)+"</td><td>"+String.valueOf(Fail)+"</td><td>"+String.format("%.2f%%",failpercentage)+"</td></tr>");
			
        File htmlTemplateFile = new File(dir+props.getProperty("SI_Report_new"));
        Charset.forName("UTF-8");
        String htmlString = FileUtils.readFileToString(htmlTemplateFile);
        htmlString = htmlString.replace("{OREtable}", htmlvalue);
        htmlString = htmlString.replace("bgcolor='#3c1d6b'", "style='background-color:#3c1d6b'");
        File newHtmlFile = new File(dir+props.getProperty("ORE_Output_Report"));
        FileUtils.writeStringToFile(newHtmlFile, htmlString);
        
        File htmldashboardTemplateFile = new File(dir+props.getProperty("ORE_Dashboard_template"));
        Charset.forName("UTF-8");
        String htmlStringDashboard = FileUtils.readFileToString(htmldashboardTemplateFile);
        htmlStringDashboard = htmlStringDashboard.replace("${table}", OREhtmlValue);
        htmlStringDashboard = htmlStringDashboard.replace("bgcolor='#3c1d6b'", "style='background-color:#3c1d6b'");
        File newHtmlFileDashboard = new File(dir+props.getProperty("ORE_Dashboard"));
        FileUtils.writeStringToFile(newHtmlFileDashboard, htmlStringDashboard);
        
		wb.close();
		
		//System.out.println("Pass count: "+Pass+" and Fail count: "+Fail);

		System.out.println("ORE Report ended..");
	}

}

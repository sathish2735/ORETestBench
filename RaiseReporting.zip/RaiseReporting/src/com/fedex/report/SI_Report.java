package com.fedex.report;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;

import com.opencsv.CSVWriter;



public class SI_Report {
	public static int Pass,Fail,Total,passcount,failcount,totalpass,totalfail;
	public static List<String> Header = new ArrayList<String>();
	public static List<String> csvpassdata = new ArrayList<String>();
	//public static int csvstringcount=0;


	static String htmlvalue="<thead bgcolor='#3c1d6b'><tr><th><font color=\"#ffffff\">Feature</font></th><th><font color=\"#ffffff\">Planned count</font></th><th bgcolor='limegreen'><font color=\"#ffffff\">Passed</font></th><th bgcolor='limegreen'><font color=\"#ffffff\">% Passed</font></th><th bgcolor='red'><font color=\"#ffffff\">Failed</font></th><th bgcolor='red'><font color=\"#ffffff\">% Failed</font></th></tr></thead>";

	public static String dir;
	public static Properties props;

	public static void pathdir() {
		dir = System.getProperty("user.dir");
		System.out.println(dir);
	}

	public static void properties() throws IOException{

		File configFile = new File("Regression_java.properties");


		FileReader reader = new FileReader(configFile);

		props = new Properties();

		// load the properties file:
		props.load(reader);
	}
	public void SIReport() throws IOException {
		System.out.println("SI Report started..");
		//for csv file

		pathdir();
		properties();
		FileInputStream Fis = new FileInputStream(dir+props.getProperty("SI_Report"));
		HSSFWorkbook wb = new HSSFWorkbook(Fis);
		for (int shcount=0; shcount<=wb.getNumberOfSheets(); shcount++){
			try{

				//count =0;
				HSSFSheet sh= wb.getSheetAt(shcount);
				Pass=0;
				Fail=0;
				int Planned = 0;
				double passpercentage = 0;
				double failpercentage = 0;

				for (int i=1;i<=sh.getLastRowNum();i++){

					DataFormatter formatter = new DataFormatter();
					String Passcount = formatter.formatCellValue(sh.getRow(i).getCell(1));

					passcount = Integer.parseInt(Passcount);
					Pass=Pass+passcount;
					String Failcount = formatter.formatCellValue(sh.getRow(i).getCell(2));
					failcount = Integer.parseInt(Failcount);
					Fail=Fail+failcount;


				}
				DataFormatter formatter = new DataFormatter();
				String Appname = formatter.formatCellValue(sh.getRow(0).getCell(0));

				Planned = Pass+Fail;

				passpercentage = ((double)Pass*100)/(double)Planned;
				failpercentage = ((double)Fail*100)/(double)Planned;


				htmlvalue=htmlvalue.concat("<tr><td><b>"+Appname+"</b></td><td>"+String.valueOf(Planned)+"</td><td>"+String.valueOf(Pass)+"</td><td>"+String.format("%.2f%%",passpercentage)+"</td><td>"+String.valueOf(Fail)+"</td><td>"+String.format("%.2f%%",failpercentage)+"</td></tr>");
				totalpass=totalpass+Pass;
				totalfail=totalfail+Fail;
				Header.add(Appname);
				DecimalFormat df = new DecimalFormat("0.00");
				csvpassdata.add(String.valueOf(df.format(passpercentage)));

			}
			catch (Exception e) {
			}


		}
		wb.close();
		int totalpassfail = totalpass+totalfail;

		double totalpasspercentage = ((double)totalpass*100)/(double)totalpassfail;
		double totalfailpercentage = ((double)totalfail*100)/(double)totalpassfail;

		htmlvalue=htmlvalue.concat("<tr style='background-color:#999999'><td><b>Total count</td><td><b>"+String.valueOf(totalpassfail)+"</td><td><b>"+String.valueOf(totalpass)+"</td><td><b>"+String.format("%.2f%%",totalpasspercentage)+"</td><td><b>"+String.valueOf(totalfail)+"</td><td><b>"+String.format("%.2f%%",totalfailpercentage)+"</td></tr>");      
		Header.add("Total Regression");
		DecimalFormat df = new DecimalFormat("0.00");
		csvpassdata.add(String.valueOf(df.format(totalpasspercentage)));

		//Old
		File htmlTemplateFile = new File(dir+props.getProperty("SI_ReportTemplete"));
		Charset.forName("UTF-8");
		String htmlString = FileUtils.readFileToString(htmlTemplateFile);
		htmlString = htmlString.replace("${divtable}", htmlvalue);
		htmlString = htmlString.replace("bgcolor='#3c1d6b'", "style='background-color:#3c1d6b'");
		File newHtmlFile = new File(dir+props.getProperty("SI_Reporthtml"));
		FileUtils.writeStringToFile(newHtmlFile, htmlString);
		
		//new
        File htmlTemplateFilenew = new File(dir+props.getProperty("DI_Reporthtml_new"));
        Charset.forName("UTF-8");
        String htmlStringnew = FileUtils.readFileToString(htmlTemplateFilenew);
        htmlStringnew = htmlStringnew.replace("${divtable}", htmlvalue);
        htmlStringnew = htmlStringnew.replace("bgcolor='#3c1d6b'", "style='background-color:#3c1d6b'");
        File new_htmlFile = new File(dir+props.getProperty("SI_Report_new"));
        FileUtils.writeStringToFile(new_htmlFile, htmlStringnew);

		        File htmldashboardtemp = new File(dir+props.getProperty("SI_DashboardReporttemp"));
		        Charset.forName("UTF-8");
		        String htmlStringdash = FileUtils.readFileToString(htmldashboardtemp);
		        htmlStringdash = htmlStringdash.replace("${table}", htmlvalue);
		        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
		        Date date = new Date();  
		        htmlStringdash = htmlStringdash.replace("${dt}", formatter.format(date));
		        htmlStringdash = htmlStringdash.replace("${pass%}",String.format("%.2f%%",totalpasspercentage));
		        htmlStringdash = htmlStringdash.replace("${pass}",String.format("%.2f",totalpasspercentage));
		        File newdashboardFile = new File(dir+props.getProperty("SI_DashboardReporthtml"));
		        FileUtils.writeStringToFile(newdashboardFile, htmlStringdash);

		//writing results to csv file so that plotting graph in jenkins dashboard would be easy

		File file = new File(dir+props.getProperty("SI_CSV"));
		try { 
			// create FileWriter object with file as parameter 
			FileWriter outputfile = new FileWriter(file); 

			// create CSVWriter object filewriter object as parameter 
			CSVWriter writer = new CSVWriter(outputfile); 

			// adding header to csv 
			//String[] header = { "Name", "Class", "Marks" }; 
			//System.out.println(Header);

			String[] header = new String[Header.size()] ;
			header = Header.toArray(header);
			writer.writeNext(header);


			// add data to csv 
			String[] Csvpassdata = new String[csvpassdata.size()] ;
			Csvpassdata = csvpassdata.toArray(header);
			writer.writeNext(Csvpassdata);

			// closing writer connection 
			writer.close(); 
		} 
		catch (IOException e) { 
			// TODO Auto-generated catch block 
			e.printStackTrace(); 
		} 


		System.out.println("SI Report ended..");
		
		ORE_Report Report =new ORE_Report();
		Report.OREReport();
	}
}

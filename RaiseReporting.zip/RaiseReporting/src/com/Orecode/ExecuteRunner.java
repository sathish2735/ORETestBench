package com.Orecode;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.Select;

import com.fedex.report.DI_Report;

public class ExecuteRunner {

	public static WebDriver driver;
	public static HashMap<String,Integer> scenarioIDRow= new HashMap<>();
	public static int scenarioNoPath=1;
	public static int scenarioNoStatus=4,passCount=0,failCount=0;
	public static String ScenarioStatus,ScenarioID,TrackingNbr;
	public static Connection connection;

	public static void main(String[] args) throws IOException, InterruptedException, SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		//TreeMap
		TreeMap<String, String> treeMap = new TreeMap<String, String>();
		//charge codes need to update as per the ORE code table but not the Green table
		
		treeMap.put("001", "Hold at Station");
		treeMap.put("010", "Direct Signature Required");
		treeMap.put("011", "Chargeable code");
		treeMap.put("012", "Delivery on Invoice Acceptance");
		treeMap.put("013", "COD");
		treeMap.put("014", "Accessible Dangerous Goods");
		treeMap.put("015", "Priority Alert");
		treeMap.put("016", "Additional Handling");
		treeMap.put("017", "Appointment");
		treeMap.put("019", "Third Party Consignee");
		treeMap.put("002", "Weekday Delivery");
		treeMap.put("020", "East Coast Special Service - Europe to US");
		treeMap.put("021", "FedEx International Mail Service");
		treeMap.put("022", "Freight to Collect");
		treeMap.put("023", "Higher Floor Charge");
		treeMap.put("024", "Rail Mode Charge");
		treeMap.put("025", "International Returns");
		treeMap.put("026", "Returns Clearance");
		treeMap.put("028", "Residential Delivery");
		treeMap.put("029", "Financial Document Option");
		treeMap.put("003", "Saturday Delivery");
		treeMap.put("031", "Saturday Hold");
		treeMap.put("033", "Sunday Delivery");
		treeMap.put("034", "Indirect Signature Required");
		treeMap.put("035", "Adult Signature Required");
		treeMap.put("036", "No Signature Required");
		treeMap.put("037", "Priority Alert Plus");
		treeMap.put("038", "On Demand Care Dry Ice");
		treeMap.put("039", "Cut Flowers");
		treeMap.put("004", "Inaccessible Dangerous Goods");
		treeMap.put("040", "Broker Selection Option");
		treeMap.put("041", "Inside Pickup");
		treeMap.put("042", "Inside Delivery");
		treeMap.put("045", "Single Shipment");
		treeMap.put("046", "Reconsignment");
		treeMap.put("047", "Mark & Tag");
		treeMap.put("048", "Delivery Reattempt");
		treeMap.put("049", "Extra Labor");
		treeMap.put("005", "Electronic Surveillance Service");
		treeMap.put("050", "Residential Pickup");
		treeMap.put("051", "Residential Delivery");
		treeMap.put("052", "Airbill Automation");
		treeMap.put("054", "Electronic Trade Documents (ETD)");
		treeMap.put("055", "Alcohol");
		treeMap.put("058", "On Demand Care Gel Packs");
		treeMap.put("059", "On Demand Care Cold Storage");
		treeMap.put("006", "Dry Ice");
		treeMap.put("060", "Special Equipment");
		treeMap.put("061", "Liftgate");
		treeMap.put("062", "Evening");
		treeMap.put("063", "Date Certain");
		treeMap.put("065", "Returns Clearance Special Routing Required");
		treeMap.put("067", "Additional Handling Surcharge -Non Stackable");
		treeMap.put("068", "Freight On Value Own Risk");
		treeMap.put("069", "Freight On Value Carrier Risk");
		treeMap.put("007", "Special Service");
		treeMap.put("070", "Return Receipt Surcharge");
		treeMap.put("071", "Pharmacy");
		treeMap.put("072", "Limited Quantity Dangerous Goods");
		treeMap.put("073", "Fully Regulated Dangerous Goods");
		treeMap.put("074", "Express local reroute");
		treeMap.put("075", "Express out of market reroute expedited");
		treeMap.put("076", "Express out of market reroute deferred");
		treeMap.put("077", "Special Delivery Instructions");
		treeMap.put("078", "Argentina- Broker Fee");
		treeMap.put("079", "Argentina- Phito Cert Fee");
		treeMap.put("008", "Address Correction");
		treeMap.put("083", "Electronic with Originals (EWO)");
		treeMap.put("085", "Split Billing Payer 1");
		treeMap.put("087", "Split Billing Payer 2-n");
		treeMap.put("088", "Holiday Delivery");
		treeMap.put("089", "Hot Pricing");
		treeMap.put("009", "Saturday Pickup");
		treeMap.put("090", "Special Delivery");
		treeMap.put("091", "Fedex International Controlled Export");
		treeMap.put("092", "International Traffic and Arms Regulation");
		treeMap.put("093", "Section II Lithium Batteries");

		

		//Excel initiation
		Exceloperations Excel = new Exceloperations();
		FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir")+"/ORE/OREinput.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
		//Getter Setter Excel
		Excel.setFileInputStream(fileInputStream);
		Excel.setWorkbook(workbook);

		//Login into ORE and returning driver instance
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KA5026469\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver()		;		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Login login = new Login();
		driver = login.Orelogin(driver, "5117988", "5117988");

		//Reading scenarios from excel and writing into HashMap with Rows

		scenarioIDRow = Excel.scenarioIdRows(System.getProperty("user.dir")+"/ORE/OREinput.xlsx", 0, 0);
		
		
		
		
		
		//Making a scenarios String with comma
		String multiplescenarioids = "";
		for (String i : scenarioIDRow.keySet())
		{
			multiplescenarioids=multiplescenarioids.concat(i).concat(",");
		}
		multiplescenarioids=multiplescenarioids.substring(0, multiplescenarioids.length()-1);
		//System.out.println("multiplescenarioids::"+multiplescenarioids);

		//Going to Driver instance and selecting filter with all given scenario id's
		driver.findElement(By.linkText("Test Scenario List")).click();
		driver.findElement(By.xpath("//input[@type=\"button\" and @value=\"Filter\"]")).click();
		driver.findElement(By.xpath("//input[@id=\"scenarioNbr\"]")).clear();
		driver.findElement(By.xpath("//input[@id=\"scenarioNbr\"]")).sendKeys(multiplescenarioids);
		Thread.sleep(5000);
		WebElement  we = driver.findElement(By.xpath("//*[@id='displayRows']"));
		Select rowstodisplay = new Select(we);
		rowstodisplay.selectByIndex(5);
		driver.findElement(By.id("performFilterBtn")).click();
		
		
		Thread.sleep(10000);

		//Clicking all scenarioId's checkbox and clicking on Execute selected
		//int count =    driver.findElements(By.xpath("//input[@type='checkbox']")).size();
		int scenarioIdCount = scenarioIDRow.size();
		//System.out.println("scenarioIdCount : "+scenarioIdCount);
		try {
			for (int ch = 0; ch <scenarioIdCount; ch++)
			{
				String path ="//input[@name='select["+ch+"]']";
				driver.findElement(By.xpath(path)).click();
			}
		} catch (Exception e) {
			e.getMessage();
		}

		//click on executed scenario id button
		driver.findElement(By.id("testScenarioListShow_testScenarioListLaunch")).click();
		//Giving some wait to load execution page
		Thread.sleep(6000);
		
		driver.findElement(By.xpath("//*[@id=\"testExecutionListShow\"]/input[1]")).click();
		WebElement  Scenariocount = driver.findElement(By.xpath("//*[@id='displayRows']"));
		Select rowstodisplay1 = new Select(Scenariocount);
		rowstodisplay1.selectByIndex(5);
		driver.findElement(By.id("performFilterBtn")).click();
		Thread.sleep(6000);
		
		//creating the data base instances
		connection=dataBase.GetConnection();
		Statement stmt = connection.createStatement();


		//Iterating all scenario ids and executing
		for (int i = 0; i <scenarioIdCount; i++) 
		{

			//Getting Scenario Id's and respective status
			ScenarioID = driver.findElement(By.xpath("//*[@id='row']/tbody/tr["+scenarioNoPath+"]/td[2]/a")).getText();
			ScenarioStatus = driver.findElement(By.xpath("//*[@id='row']/tbody/tr["+scenarioNoStatus+"]/td[5]/a")).getText();

			//System.out.println("ScenarioStatus for "+ScenarioID+" is:"+ ScenarioStatus+" and Row number is "+scenarioIDRow.get(ScenarioID));
		/*	int maxrefreshCount = 0;
			if (maxrefreshCount<3) {
				
			
			while (ScenarioStatus.equalsIgnoreCase("Pending")||ScenarioStatus.equalsIgnoreCase("Running")) {
				Thread.sleep(10000);
				driver.navigate().refresh();
				String newstatus = driver.findElement(By.xpath("//*[@id='row']/tbody/tr["+scenarioNoStatus+"]/td[5]/a")).getText();
				//System.out.println("newstatus for "+ScenarioID+"is:"+ newstatus);
				ScenarioStatus=newstatus;
				maxrefreshCount++;
			}
			}
		*/	
			int maxrefreshCount = 0;
			while(maxrefreshCount<5 && !ScenarioStatus.contains("Complete") )
			{
				//System.out.println("while entering the if code"+maxrefreshCount);
				if (ScenarioStatus.equalsIgnoreCase("Pending")||ScenarioStatus.equalsIgnoreCase("Running")) {
					Thread.sleep(5000);
					driver.navigate().refresh();
					}
				String newstatus = driver.findElement(By.xpath("//*[@id='row']/tbody/tr["+scenarioNoStatus+"]/td[5]/a")).getText();
				//System.out.println("newstatus for "+ScenarioID+"is:"+ newstatus);
				ScenarioStatus=newstatus;
				maxrefreshCount++;
				//System.out.println("after finishing the code"+maxrefreshCount);
			}
			
		
			//Hardcoding values need to remove
			String latestStatus=driver.findElement(By.xpath("//*[@id='row']/tbody/tr["+scenarioNoStatus+"]/td[5]/a")).getText().toString();
			//String latestStatus="Complete";
			TrackingNbr = driver.findElement(By.xpath("//*[@id='row']/tbody/tr["+scenarioNoPath+"]/td[8]")).getText();
			//TrackingNbr = "552061414226" ;
			
			if (!latestStatus.equalsIgnoreCase("")) {

				String passList= "";
				String failList= "";

				passCount = 0;
				failCount = 0;

			int	 RowValue = scenarioIDRow.get(ScenarioID);
				int expectedColNbr = 4;

				String expectedValues = Excel.Read(0, RowValue, expectedColNbr);

				String[] AllValidations = expectedValues.split(",");
				/// Need to implement catch

				for (int j = 0; j < AllValidations.length; j++) {

					String[] AllScenarioNames = AllValidations[j].split(":");

					String ScenarioName = AllScenarioNames[j];

					//Switch case

					switch (ScenarioName) {
					case "ChargeCode":

						for (int k = 1; k < AllScenarioNames.length; k++) {

							String[] ExpectedValues = AllScenarioNames[k].split(";");

							String chargeCode =ExpectedValues[0].toString();

							String expectedChargeAmount = ExpectedValues[1].toString();

							

							ResultSet rs= stmt.executeQuery("select a.ONLN_BILL_TO_AMT from INTL_EXPRS_ONLN_SCHEMA.INTL_ONLINE_CHARGE_ITEM a join INTL_EXPRS_ONLN_SCHEMA.INTL_PACKAGE b on a.ONLN_REV_ITEM_ID=b.ONLN_REV_ITEM_ID where b.PKG_TRKNG_NBR ='"+TrackingNbr+"' and a.CHRG_CD='"+chargeCode+"'");

							String actualChargeAmount="0";
							while (rs.next()) {
								actualChargeAmount=rs.getString(1);
							}

							if(expectedChargeAmount.contentEquals(actualChargeAmount)) {

								passList = passList.concat(treeMap.get(chargeCode)+" has been Passed;");

								passCount++;

							}

							else {
								failList = failList.concat(treeMap.get(chargeCode)+" has been Failed;");
								failCount++;	
							}

						}
						
						

						break;

						default:
						break;
					}

					
					
				}
				
				Excel.write(0, RowValue, 2,TrackingNbr);
				Excel.write(0, RowValue, 5,passList);
				Excel.write(0, RowValue, 6,failList);
				Excel.write(0, RowValue, 7,String.valueOf(passCount));
				Excel.write(0, RowValue, 8,String.valueOf(failCount));
				if(failCount==0) {
					Excel.write(0, RowValue, 9,"Passed");
				}
				else {
					Excel.write(0, RowValue, 9,"Failed");
				}

			} 

			//If status is not Completed (It may be Error ,cancelled ,Running,pending)		
			else {
				int  RowValue = scenarioIDRow.get(ScenarioID);
				Excel.write(0, RowValue, 9,latestStatus);
			}

			scenarioNoPath+=4;
			scenarioNoStatus+=4;
		}

		connection.close();
		
		DI_Report Report= new DI_Report();
		Report.DIReport();
	}


}

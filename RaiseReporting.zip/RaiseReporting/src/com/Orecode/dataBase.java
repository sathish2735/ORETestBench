package com.Orecode;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dataBase {

	public static Connection  GetConnection() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {

		Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();

		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@basic://idb00214.ute.fedex.com:1526/ST1DB4","super_app","super_app");

		return con;
	}

}

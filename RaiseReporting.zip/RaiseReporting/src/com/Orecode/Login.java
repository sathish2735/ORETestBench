package com.Orecode;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login {
	
	
	public WebDriver Orelogin(WebDriver driver,String username,String pwd) {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    driver.get("https://devoretce13.prod.fedex.com:9007/oreTestBench");
	    //clear everything
	    driver.findElement(By.xpath("/html/body/div[3]/div/form/input[2]")).click();
	                
	    driver.findElement(By.xpath("//input[@name=\"j_username\"]")).sendKeys(username);
	    
	    driver.findElement(By.xpath("//input[@name=\"j_password\"]")).sendKeys(pwd);
	    
	   driver.findElement(By.xpath("//input[@value=\"Login\"]")).click();
	   return driver;

	}

}

package com.Orecode;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class Exceloperations {
	static String scenarioid;
	public static Row row;
	public static Cell cell;
	public static TreeMap<Integer, String> data;
	public static String value;
	static XSSFSheet Sh;
	static int rowvalue ;
	public static HashMap<String,Integer> scenarioIDRow= new HashMap<>();
	public static FileInputStream fileInputStream;
	public static XSSFWorkbook workbook;
	
	public static FileInputStream getFileInputStream() {
		return fileInputStream;
	}

	public void setFileInputStream(FileInputStream fileInputStream) {
		Exceloperations.fileInputStream = fileInputStream;
	}

	public static XSSFWorkbook getWorkbook() {
		return workbook;
	}

	public void setWorkbook(XSSFWorkbook workbook) {
		Exceloperations.workbook = workbook;
	}



	public String Read(int sheet, int rownbr,int coloumnnbr) throws IOException   {
		XSSFSheet Sh = getWorkbook().getSheetAt(sheet);
		String cellValue =Sh.getRow(rownbr).getCell(coloumnnbr).getStringCellValue().toString();
		//rowvalue = Sh.getLastRowNum();
		return cellValue;
	}



	public void write(int sheet, int rownbr,int coloumnnbr, String WrtieValue) throws IOException   {
		XSSFSheet Sh = getWorkbook().getSheetAt(sheet);
		row = Sh.getRow(rownbr);
		cell=row.getCell(coloumnnbr);
		cell.setCellType(cell.CELL_TYPE_STRING);
		cell.setCellValue(WrtieValue);
		FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir")+"/ORE/OREinput.xlsx");
		getWorkbook().write(fos);
		fos.close();
		System.out.println("END OF WRITING DATA IN EXCEL");
	}

	public HashMap<String, Integer> scenarioIdRows(String sheetName,int sheetIndex,int coloumnnbr) throws IOException {

		FileInputStream fis = new FileInputStream(sheetName);
		XSSFWorkbook Wb = new XSSFWorkbook(fis);
		XSSFSheet Sh = Wb.getSheetAt(sheetIndex);
		int rowvalue = Sh.getLastRowNum();
		for (int i = 1; i <=rowvalue; i++) {
			scenarioIDRow.put(Sh.getRow(i).getCell(coloumnnbr).getStringCellValue().toString(), i);
		}
		Wb.close();

		return scenarioIDRow;
	}



}



